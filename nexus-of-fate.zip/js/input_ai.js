function input_ai() {
  // currently unused.
  // this function used to control the AI with keypresses
  // and would update this.keys[] array
  // so it followed all the same fighter.js logic as the player
  // but since we've decided to have the robot use different logic
  // it made no sense to have AI control itself like a player
}
