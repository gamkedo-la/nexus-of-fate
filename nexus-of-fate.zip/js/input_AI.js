function input_ai(){
	
}